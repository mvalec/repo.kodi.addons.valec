# -*- coding: UTF-8 -*-
# /*
# *      Copyright (C) 2019 Miro "Valec" Valko
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */

import sys
import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET
import traceback
import time
from hashlib import md5
from simpleplugin import Storage
from shutil import copyfile
import cPickle as pickle


ADDON         = xbmcaddon.Addon('script.valec.skpatch')
ADDON_NAME    = ADDON.getAddonInfo('name')
ADDON_ID      = ADDON.getAddonInfo('id')
ADDON_VERSION = ADDON.getAddonInfo('version')
CWD           = ADDON.getAddonInfo('path')
PATCH_RES_DIR = os.path.join(CWD, 'resources', 'data').decode('utf-8', 'ignore')
DATAROOT      = xbmc.translatePath(ADDON.getAddonInfo('profile')).decode('utf-8', 'ignore')
DATANAME      = 'addondb.dat'


def compareVersions(ver1, ver2):
    v1 = tuple(map(int, (ver1.split("."))))
    v2 = tuple(map(int, (ver2.split("."))))
    if (v1 > v2):
        return 1
    elif (v1 < v2):
        return -1
    else:
        return 0


def localized(id):
    return ADDON.getLocalizedString(id)


def ShowError(msgStr1, msgStr2='', msgStr3=''):
    if msgStr3 == "":
        msgStr3 = xbmc.getLocalizedString(2104)
    xbmcgui.Dialog().ok('%s - %s !!!' % (ADDON_NAME,  xbmc.getLocalizedString(257)), msgStr1, msgStr2, msgStr3)


def ShowInfo(msgStr1, msgStr2='', msgStr3=''):
    xbmcgui.Dialog().ok('%s - %s !!!' % (ADDON_NAME,  xbmc.getLocalizedString(14116)), msgStr1, msgStr2, msgStr3)


def getNotifyInterval(intID=1):
    # get number o min for notification interval, by settings enum id, defaul is id 1
    return {
        0: -100,    # only once
        1: 10,      # every 10 min
        2: 30,      # every 30 min
        3: 60,      # every 1 hour
        4: 120,     # every 2 hour
        5: 240,     # every 4 hour
        }.get(intID, 10)


class PatchBaseError(Exception):

    def __init__(self, object, message, dlgMessage, originalErr=None):
        Exception.__init__(self, message)
        self.dlgMessage = dlgMessage
        self.originalErr = str(originalErr) if originalErr else None
        if object:
            if originalErr:
                object.logError(str(originalErr.message) + '\n' + traceback.format_exc(originalErr))
            object.logError(message)

    def __str__(self, *args, **kwargs):
        return Exception.__str__(self, *args, **kwargs)


class ApplyPatchError(PatchBaseError):

    def __init__(self, addonItem, message, modified, dlgMessage=None, originalErr=None):
        if not dlgMessage:
            dlgMessage = localized(32106) % (addonItem.name, addonItem.addonID)
            if modified:
                dlgMessage += '\n' + localized(32105)
        PatchBaseError.__init__(self, addonItem, 'Applying patch failed - %s' % message, dlgMessage, originalErr)


class PatchDefsError(PatchBaseError):

    def __init__(self, addonItem, message, dlgMessage=None, originalErr=None):
        if not dlgMessage:
            dlgMessage = localized(32107) % (addonItem.name, addonItem.addonID)
        PatchBaseError.__init__(self, addonItem, 'Patch definition file error: %s\nFile: %s' % (message, addonItem.patchFile),
                                dlgMessage, originalErr)


class DataStorage(Storage):

    def flush(self, invalidate=True):
        contents = pickle.dumps(self._storage, protocol=2)
        if self._hash is None or md5(contents).hexdigest() != self._hash:
            tmp = self._filename + '.tmp'
            start = time.time()
            while os.path.exists(tmp):
                if time.time() - start > 2.0:
                    raise TimeoutError(
                        'Exceeded timeout for saving {0} contents!'.format(self)
                    )
                xbmc.sleep(100)
            try:
                with open(tmp, 'wb') as fo:
                    fo.write(contents)
                copyfile(tmp, self._filename)
            finally:
                os.remove(tmp)
        if invalidate:
            del self._storage


_STORAGE = None


def GlobalStorage():
    global _STORAGE
    if _STORAGE is None:
        _STORAGE = DataStorage(DATAROOT, DATANAME)
    return _STORAGE


def FreeGlobalStorage():
    global _STORAGE
    if _STORAGE:
        del _STORAGE
        _STORAGE = None


def SaveGlobalStorage():
    global _STORAGE
    if _STORAGE:
        _STORAGE.flush(False)


class BaseClass:

    def __logPrefix__(self):
        return '[%s] ' % ADDON_NAME

    def __settingPrefix__(self):
        return ''

    def getSettingStr(self, id, makeBlank=False):
        try:
            return GlobalStorage()[self.__settingPrefix__()+id]
        except:
            if makeBlank:
                self.setSettingStr(id, '')
            return None

    def getSettingStrDef(self, id, defValue='', makeBlank=False):
        try:
            return GlobalStorage()[self.__settingPrefix__()+id]

        except:
            if makeBlank:
                self.setSettingStr(id, '')
            return defValue

    def isLoggingEnabled(self):
        return True

    def logMessage(self, msgStr, level=xbmc.LOGNOTICE):
        if isinstance(msgStr, unicode):
            msgStr = msgStr.encode('utf-8')
        xbmc.log('%s%s' % (self.__logPrefix__(), msgStr.__str__()), level)

    def logDebug(self, msgStr):
        self.logMessage(msgStr, level=xbmc.LOGDEBUG)

    def logError(self, msgStr):
        self.logMessage(msgStr, level=xbmc.LOGERROR)

    def logInfo(self, msgStr):
        if self.isLoggingEnabled() or xbmc.getCondVisibility('System.GetBool(debug.showloginfo)'):
            self.logMessage(msgStr, level=xbmc.LOGNOTICE)

    def logWarning(self, msgStr):
        if self.isLoggingEnabled() or xbmc.getCondVisibility('System.GetBool(debug.showloginfo)'):
            self.logMessage(msgStr, level=xbmc.LOGWARNING)

    def removeSettingStr(self, id):
        try:
            del GlobalStorage()[self.__settingPrefix__()+id]
        except Exception:
            pass

    def setSettingStr(self, id, value=''):
        try:
            GlobalStorage()[self.__settingPrefix__()+id] = value
        except Exception as err:
            raise PatchBaseError(self, 'Set settings failed.', '', err)


class AddonItem(BaseClass):

    def __init__(self, owner, addonID, addonName='', doUpdateStatus=False):
        self.owner = owner
        self.addonID = addonID
        self.name = addonID if addonName == '' else addonName
        self.name2 = addonName
        self.version = ''
        self.dataVersion = ''
        self.patchVersions = {}
        self.applyPatchResult = 0  # not applied
        self.addonIsInstalled = False
        self.enabled = False
        self.srcPath = os.path.join(PATCH_RES_DIR, addonID)
        self.patchFile = os.path.join(self.srcPath, 'patch.xml')
        self.checkPatchDefsFile()
        if doUpdateStatus:
            self.updateStatus()

    def __logPrefix__(self):
        if self.owner:
            return '%sPatch: %s: ' % (self.owner.__logPrefix__(), self.addonID)
        else:
            return '[%s] Patch: %s: ' % (ADDON_NAME, self.addonID)

    def __settingPrefix__(self):
        return self.addonID+'.'

    def applyPatch(self, progress, lastidx, total):
        self.applyPatchResult = 0  # 0 = not patched, not applied
        if not self.isEnabledToPatch():
            return self.applyPatchResult
        try:
            px = 100/float(total)
            perc = int(px * lastidx)
            progress.update(perc, '', '%s [%s]' % (self.name, self.addonID), ' ')
            xbmc.sleep(50)
            modified = False
            actcount = 0
            if not xbmcvfs.exists(self.patchFile):
                raise ApplyPatchError(self, 'File not found.\nFile: %s' % self.patchFile, False, dlgMessage=localized(32108) % (self.name, self.addonID))
            tree = ET.parse(self.patchFile.decode('utf-8'))
            patchNode = tree.getroot().find("./patch[@id='%s']" % self.validPatchID)
            if patchNode is None:
                raise ApplyPatchError(self, 'Can not find patch id=%s in patch defs file.' % self.validPatchID, False,
                                      dlgMessage=localized(32107) % (self.name, self.addonID))
            try:
                for action in patchNode.findall('action'):
                    perc = int(px * (lastidx + actcount))
                    progress.update(perc)
                    xbmc.sleep(50)
                    actcount += 1
                    fn = action.get('file')
                    at = action.get('type').upper()
                    if (at == 'NOP'):
                        # no operation
                        progress.update(perc, '', '', ' ')
                        self.logDebug('Action %d/%d: ID=%s, type=NOP' % (actcount, self.actionsCount, action.get('id')))
                    elif (at == 'COPYFILE'):
                        # copy file
                        progress.update(perc, '', '', localized(32101) % fn)
                        srcfile = os.path.join(self.srcPath, action.get('source', fn))
                        destfile = os.path.join(self.destPath, fn)
                        self.logDebug('Action %d/%d: ID=%s, type=COPYFILE\nSource: %s\nDestination: %s' %
                                      (actcount, self.actionsCount, action.get('id'), srcfile, destfile))
                        if xbmcvfs.exists(srcfile):
                            if xbmcvfs.copy(srcfile, destfile):
                                modified = True
                            else:
                                raise ApplyPatchError(self, 'Copy file failed: %s' % srcfile, modified)
                        else:
                            raise ApplyPatchError(self, 'Copy file failed. Source file not found: ' % srcfile, modified)
                    elif (at == 'XMLUPDATE'):
                        # update xml file
                        xml_modified = False
                        progress.update(perc, '', '', localized(32102) % (fn))
                        destfile = os.path.join(self.destPath, fn)
                        self.logDebug('Action %d/%d: ID=%s, type=XMLUPDATE\nDestination: %s' %
                                      (actcount, self.actionsCount, action.get('id'), destfile))
                        if xbmcvfs.exists(destfile):
                            dest_tree = ET.parse(destfile.decode('utf-8'))
                            dest_root = dest_tree.getroot()
                            # process all nodes with tag='element'
                            for elm in action.findall('element'):
                                xpath = elm.get('xpath')
                                keyattrs = elm.get('keyattrs')
                                fkeys = []
                                allatributes = (keyattrs is None) or (keyattrs == '')
                                if not allatributes:
                                    # make list of attribute keys from keyattrs
                                    for k in fkeysstr.split(','):
                                        fkeys.append(k.strip())
                                # find node in destiantion xml by using xpath
                                dest_parent = dest_root.find(xpath)
                                if dest_parent is None:
                                    raise ApplyPatchError(self, "Can't find xml element with xpath=%s in file \n%s" % (xpath, destfile), modified)
                                # process all subitems of element
                                for item in elm.findall("./*"):
                                    new_element = item.copy()
                                    # get same element position in original file
                                    query = './' + item.tag
                                    if allatributes:
                                        fkeys = item.attrib.keys()
                                    # make query string for check if destination node exists
                                    for attr in fkeys:
                                        aq = "[@%s='%s']" % (attr, item.get(attr))
                                        query += aq
                                    dest_element = dest_parent.find(query)
                                    if dest_element is not None:
                                        # same element exists, get index and replace
                                        idx = dest_parent._children.index(dest_element)
                                        new_element.tail = dest_element.tail
                                        dest_parent.__setitem__(idx, new_element)
                                        xml_modified = True
                                    else:
                                        # element does not exists, find last similar
                                        query = './' + item.tag + '[last()]'
                                        dest_element = dest_parent.find(query)
                                        if dest_element is not None:
                                            # similar element exists, get the index
                                            new_element.tail = dest_element.tail
                                            idx = dest_parent._children.index(dest_element)
                                            dest_parent.insert(idx+1, new_element)
                                        else:
                                            dest_parent.append(new_element)
                                        xml_modified = True
                            if xml_modified:
                                modified = True
                                # save modified xml file
                                dest_tree.write(destfile.decode('utf-8'), encoding="utf-8", xml_declaration=True)
                        else:
                            raise ApplyPatchError(self, 'Destination file not found: %s' % destfile, modified)
                perc = int(px*(lastidx+self.actionsCount))
                progress.update(perc)
                # save md5 hash of addon.xml and current version of addon and patch
                self.setSettingStr('hash', self.getMD5ofAddon())
                self.setSettingStr('last_ver', self.version)
                self.setSettingStr('last_patch', self.dataVersion)
                SaveGlobalStorage()
                self.applyPatchResult = 2 if modified else 1  # patch OK, 2 = addon modified, 1 = addon untouched
            except ApplyPatchError:
                raise
            except Exception as err:
                raise ApplyPatchError(self, 'A error has occured: %s' % str(err), modified, originalErr=err)
        except PatchBaseError as err:
            self.applyPatchResult = -2 if modified else -1  # patching failed, -2 = addon modified, -1 = addon untouched
            if self.owner:
                self.owner.showError(err.dlgMessage)
        except Exception as err:
            raise ApplyPatchError(self, 'A error has occured: %s' % str(err), modified, originalErr=err)
        finally:
            return self.applyPatchResult

    def isEnabledToPatch(self):
        return self.addonIsInstalled and self.validPatchID and (self.enabled) and not self.isSkippedVersion()

    def isLoggingEnabled(self):
        return self.owner.isLoggingEnabled() if self.owner else True

    def isSkippedVersion(self):
        return self.addonIsInstalled and self.validPatchID and (self.actionsCount == 0)

    def getMD5ofAddon(self):
        if self.addonIsInstalled:
            afile = os.path.join(self.destPath, "addon.xml").decode('utf-8')
            m = md5(open(afile, "r").read())
            m.update(self.dataVersion)
            return m.hexdigest()
        else:
            return None

    def checkPatchDefsFile(self):
        # validate file patch.xml, check basic structure
        validtypes = ['COPYFILE', 'XMLUPDATE', 'NOP']
        self.patchVersions.clear()
        self.validPatchID = None
        if xbmcvfs.exists(self.patchFile):
            try:
                tree = ET.parse(self.patchFile.decode('utf-8'))
                root = tree.getroot()
                aid = root.get('id')
                if (root.tag == 'addon') & (aid == self.addonID):
                    if self.name2 == '':
                        self.name2 = root.get('name')
                    self.dataVersion = root.get('patch', 'skpatch.' + ADDON_VERSION)
                    # syntax check all patch nodes
                    for patch_elem in root.findall('patch'):
                        pID = patch_elem.get('id')
                        if (not pID) or (pID == ''):
                            raise PatchDefsError(self, 'Missing patch id.')
                        pVersions = patch_elem.get('versions', 'all')
                        self.isValidVersion(pVersions, pID, checkSyntaxOnly=True)
                        pActions = 0
                        for action in patch_elem.findall('action'):
                            at = action.attrib.get('type')
                            if at is None:
                                raise PatchDefsError(self, 'Missing type of action. [Patch id = %s, Action id = %s]' % (pID, action.get('id')))
                            at = at.upper()
                            if validtypes.count(at) == 0:
                                raise PatchDefsError(self, 'Invalid type of action: %s [Patch id = %s, Action id = %s]' % (at, pID, action.get('id')))
                            fn = action.attrib.get('file')
                            if (at != 'NOP') and ((fn is None) or (fn == '')):
                                raise PatchDefsError(self, 'Missing file definition for action. [Patch id = %s, Action id = %s]' % (pID, action.get('id')))
                            if (at == 'COPYFILE'):
                                srcfile = os.path.join(self.srcPath, action.get('source', fn))
                                if not xbmcvfs.exists(srcfile):
                                    raise PatchDefsError(self, 'Invalid file definition for action. [Patch id = %s, Action id = %s] Source file not found.\nMissing file: %s' % (
                                        pID, action.get('id'), srcfile))
                            pActions += 1
                        self.patchVersions[pID] = {}
                        self.patchVersions[pID]['vers'] = pVersions
                        self.patchVersions[pID]['acts'] = pActions
                else:
                    raise PatchDefsError(self, 'Invalid <addon id=xxx> element.')
                if self.addonIsInstalled:
                    for pID in self.patchVersions.keys():
                        if self.isValidVersion(self.patchVersions[pID]['vers'], pID):
                            self.validPatchID = pID
                            break
            except PatchDefsError:
                self.patchVersions.clear()
                raise
            except Exception as err:
                self.patchVersions.clear()
                raise PatchDefsError(self, 'A error has occured: %s' % str(err), originalErr=err)
        else:
            raise PatchDefsError(self, 'File not found.', dlgMessage=localized(32108) % (self.name, self.addonID))

    def checkPatchStatus(self):
        res = False
        if self.addonIsInstalled:
            currMD5 = self.getMD5ofAddon()
            savedMD5 = self.getSettingStr('hash')
            res = (currMD5 is not None) & (savedMD5 is not None) & (currMD5 == savedMD5)
        return res

    def isValidVersion(self, versions, patchID, checkSyntaxOnly=False):
        if (versions == '') or (versions == 'all'):
            return True
        verlist = versions.split(',')
        for veritem in verlist:
            vl = veritem.strip().split(':')
            if len(vl) == 1:
                vmin = vl[0].strip()
                vmax = vmin
            elif len(vl) == 2:
                vmin = vl[0].strip()
                vmax = vl[1].strip()
            else:
                raise PatchDefsError(self, 'Invalid version definition: "%s". [Patch id = %s]' % (versions, patchID))
            if not checkSyntaxOnly:
                cmpmin = compareVersions(self.version, vmin)
                cmpmax = compareVersions(self.version, vmax)
                if (cmpmin >= 0) and (cmpmax <= 0):
                    return True
        return False

    def updatePatchStatus(self):
        self.addonIsPatched = self.checkPatchStatus()

    def updateStatus(self):
        self.validPatchID = None
        self.actionsCount = 0
        self.addonIsInstalled = xbmc.getCondVisibility("System.HasAddon(%s)" % self.addonID)
        try:
            self.enabled = ADDON.getSettingBool(self.addonID)
        except:
            self.enabled = False
        savedMD5 = self.getSettingStrDef('hash')
        lastVer = self.getSettingStrDef('last_ver')
        lastPatch = self.getSettingStrDef('last_patch')
        if self.addonIsInstalled:
            dest_addon = xbmcaddon.Addon(self.addonID)
            self.name = dest_addon.getAddonInfo('name')
            self.version = dest_addon.getAddonInfo('version')
            self.destPath = dest_addon.getAddonInfo('path')
            del dest_addon
            for pID in self.patchVersions.keys():
                if self.isValidVersion(self.patchVersions[pID]['vers'], pID):
                    self.validPatchID = pID
                    self.actionsCount = self.patchVersions[pID]['acts']
                    break
            self.updatePatchStatus()
            if self.addonIsPatched:
                self.logInfo('[ver: %s] Addon is already patched.' % self.version)
            else:
                if self.isSkippedVersion():
                    self.logInfo('[ver: %s] This version of the add-on does not need any patch.' % self.version)
                elif (savedMD5 == ''):
                    self.logInfo('[ver: %s] Addon has not been patched yet.' % self.version)
                elif (self.version == lastVer):
                    if (self.dataVersion == lastPatch):
                        self.logInfo('[ver: %s] Addon is not patched. It was reinstalled after last patch (ver: %s).' % (self.version, self.dataVersion))
                    else:
                        self.logInfo('[ver: %s] Addon is not patched. New version of patch found (ver: %s).' % (self.version, self.dataVersion))
                else:
                    if (self.dataVersion == lastPatch):
                        self.logInfo('[ver: %s] Addon is not patched. It was updated after last patch. (Last patched ver: %s by patch ver: %s)' % (self.version, lastVer, lastPatch))
                    else:
                        self.logInfo('[ver: %s] Addon is not patched. It was reinstalled and new version of patch found (ver: %s).' % (self.version, self.dataVersion))
            if self.validPatchID:
                self.logDebug('[ver: %s] Valid version of patch is found. Patch id=%s, actions: %d' % (self.version, self.validPatchID, self.actionsCount))
            else:
                self.logWarning('[ver: %s] No valid version of patch is found.' % self.version)
        else:
            self.addonIsPatched = False
            self.version = ''
            self.name = self.name2
            self.logInfo('Addon is not installed.')


class AddonList(BaseClass):

    def __init__(self, owner=None):
        self.items = []
        self.owner = owner
        self.dialogsEnabled = True
        self.loggingInfosEnabled = True
        self.defsIsValid = False

    def __logPrefix__(self):
        if self.owner:
            return self.owner.__logPrefix__()
        else:
            return '[%s] ' % ADDON_NAME

    def addAddon(self, addonID, addonName=''):
        self.logDebug('Adding addon %s to list' % addonID)
        if self.getAddonItem(addonID):
            raise PatchBaseError(self, 'Duplicate addonID.', '')
        self.items.append(AddonItem(self, addonID, addonName, False))

    def doPatchAddons(self, UpdateStatuses=True):
        self.logInfo('Fix process preparing ...')
        errExists = False
        doRestart = False
        if UpdateStatuses:
            self.updateAddonStatuses(checkDefs=True, showErrors=True, loggingInfos=True)
        if not self.defsIsValid:
            self.logError('Fix process terminated. Patch definitions is not valid.')
            return
        lastidx = 0
        total = self.getActionsCount()
        if total > 0:
            self.logInfo('Fix process started')
            progress = xbmcgui.DialogProgress()
            progress.create(ADDON_NAME, localized(32103))
            for addon_item in self.items:
                if addon_item.isEnabledToPatch():
                    addon_item.applyPatch(progress, lastidx, total)
                    if addon_item.applyPatchResult < 0:
                        errExists = True
                    if addon_item.applyPatchResult in [-2, 2]:
                        # addon was modified
                        doRestart = True
                    lastidx += addon_item.actionsCount
            progress.update(100, localized(32104), ' ', ' ')
            xbmc.sleep(1000)
            progress.close()
            self.logInfo('Fix process finished.')
        else:
            ShowInfo(localized(32128))
        # clean unused settings
        for addon_item in self.items:
            if not addon_item.addonIsInstalled:
                addon_item.removeSettingStr('hash')
                addon_item.removeSettingStr('last_ver')
                addon_item.removeSettingStr('last_patch')
        SaveGlobalStorage()
        if errExists:
            xbmcgui.Dialog().notification(ADDON_NAME + ' ' + xbmc.getLocalizedString(257), localized(32122) + ' ' + xbmc.getLocalizedString(2104),
                                          xbmcgui.NOTIFICATION_ERROR, time=5000)
        if ADDON.getSettingBool('show_results'):
            self.showUpdateInfo()
        if doRestart:
            if xbmcgui.Dialog().yesno(ADDON_NAME, localized(32120), '', localized(32121)):
                self.logInfo('Restart of Kodi invoked by user.')
                xbmc.executebuiltin('RestartApp')

    def getActionsCount(self):
        total = 0
        for addon_item in self.items:
            if addon_item.isEnabledToPatch():
                total += addon_item.actionsCount
        return total

    def getAddonItem(self, addonID):
        for addon_item in self.items:
            if addon_item.addonID == addonID:
                return addon_item
        return None

    def getAddonStatuses(self):
        # return 4 values: installed, patched, actions, status_hash
        installed = 0
        patched = 0
        actions = 0
        m = md5()
        for addon_item in self.items:
            if addon_item.addonIsInstalled and addon_item.enabled:
                installed += 1
                if addon_item.addonIsPatched:
                    patched += 1
                elif addon_item.isEnabledToPatch():
                    actions += addon_item.actionsCount
                    m.update(addon_item.addonID)
        m.update('%d-%d-%d' % (installed, patched, actions))
        return installed, patched, actions, m.hexdigest()

    def getAddonName(self, id):
        # helper func to sort by addonName
        res = self.getAddonItem(id)
        return res.name.lower() if res else id

    def genSettingsFile(self):
        try:
            self.updateAddonStatuses(True, False, True)
            # make list of addons ids
            idlist = []
            for addon_item in self.items:
                idlist.append(addon_item.addonID)
            # sort by name
            idlist.sort(key=self.getAddonName)

            fname = os.path.join(CWD, 'resources', 'settings.xml').decode('utf-8')
            xml_lines = open(fname, 'rb').read().decode('utf-8').splitlines()
            data_xml1 = ''
            for line in xml_lines:
                # check end of settings
                if (line.find('</settings>') >= 0):
                    break
                data_xml1 += line + '\n'
                # find <!-- add-ons -->
                if (line.find("<!-- Add-ons -->") >= 0):
                    break
            # start of category for addons
            data_xml1 += '    <category label=32001>\n'
            data_xml1 += '        <setting label="32020" type="lsep"/>\n'
            data_xml2 = data_xml1
            data_xml3 = data_xml1
            for id in idlist:
                addon_item = self.getAddonItem(id)
                data_xml1 += '        <!-- {} -->\n'.format(id)
                data_xml1 += '        <setting label="$INFO[System.AddonTitle({0})]" id="{0}" visible="System.HasAddon({0})" type="bool" default="true"/>\n'.format(id)
                data_xml1 += '        <setting label="{0}" id="{0}.ni" visible="!System.HasAddon({0})" enable="false" type="enum" lvalues="32009"/>\n'.format(id)
                data_xml2 += '        <setting label="$INFO[System.AddonTitle({0})]" id="{0}" visible="System.HasAddon({0})" type="bool" default="true"/>\n'.format(id)
                data_xml3 += '        <setting label="$INFO[System.AddonTitle({0}),, - ]{0}" id="{0}" enable="System.HasAddon({0})" type="bool" default="true"/>\n'.format(id)
            # idlist.sort()
            data_xml2 += '        <!-- for not installed add-ons -->\n'
            data_xml2 += '        <setting label="32021" type="lsep"/>\n'
            for id in idlist:
                addon_item = self.getAddonItem(id)
                data_xml2 += '        <setting label="{1} [{0}]" visible="!System.HasAddon({0})" enable="false" type="action" action="InstallAddon({0})"/>\n'.format(id, addon_item.name)
            data_xml1 += '    </category>\n'
            data_xml2 += '    </category>\n'
            data_xml3 += '    </category>\n'
            data_xml1 += '</settings>\n'
            data_xml2 += '</settings>\n'
            data_xml3 += '</settings>\n'
            path = xbmc.translatePath('special://temp').decode('utf-8')
            fname = os.path.join(path, 'settings1.xml')
            self.logInfo('Write settings template to ' + fname)
            open(fname, "wb").write(data_xml1)
            fname = os.path.join(path, 'settings2.xml')
            open(fname, "wb").write(data_xml2)
            fname = os.path.join(path, 'settings3.xml')
            open(fname, "wb").write(data_xml3)
            desc = ''
            idlist.sort()
            for id in idlist:
                desc += '[CR]%s' % id
            fname = os.path.join(path, 'desc.txt')
            open(fname, "wb").write(desc)
        except Exception as err:
            self.logError(err.message + '\n' + traceback.format_exc(err))
            self.logError('Creating of file settings.xml failed')

    def isLoggingEnabled(self):
        return self.loggingInfosEnabled

    def checkPatchDefs(self, all=True, showErrors=True):
        save = self.dialogsEnabled
        try:
            self.dialogsEnabled = showErrors
            for addon_item in self.items:
                if (addon_item.addonIsInstalled or all):
                    addon_item.checkPatchDefsFile()
            self.defsIsValid = True
            return True
        except PatchDefsError as err:
            self.defsIsValid = False
            msg = xbmc.getLocalizedString(2104) if showErrors else err.dlgMessage
            xbmcgui.Dialog().notification(ADDON_NAME + ' ' + xbmc.getLocalizedString(257), msg, xbmcgui.NOTIFICATION_ERROR, time=5000)
        finally:
            self.dialogsEnabled = save

    def showError(self, msgStr1, msgStr2='', msgStr3=''):
        if self.dialogsEnabled:
            ShowError(msgStr1, msgStr2, msgStr3)

    def showUpdateInfo(self):
        self.logDebug('Summary report generating started ...')
        report = '[B]%s[/B] \n' % localized(32109)
        i = 0
        idlen = 2 if len(self.items) > 9 else 1
        # make list of addons ids
        idlist = []
        for addon_item in self.items:
            idlist.append(addon_item.addonID)
        # sort by name
        idlist.sort(key=self.getAddonName)

        for id in idlist:
            addon_item = self.getAddonItem(id)
            i += 1
            report += '\n%*.*d/%d - [B]%s[/B]\n    [COLOR gray][%s] %s %s[/COLOR]\n    ... ' % (
                idlen, idlen, i, len(self.items), addon_item.name, addon_item.addonID, localized(32110) if addon_item.addonIsInstalled else '', addon_item.version)
            if addon_item.addonIsInstalled:
                if addon_item.isEnabledToPatch():
                    if addon_item.applyPatchResult > 0:
                        report += '[COLOR lime]%s' % localized(32111)  # OK
                        if addon_item.applyPatchResult == 1:
                            report += ', %s' % localized(32112)  # no changes
                        report += '[/COLOR]'
                    elif addon_item.applyPatchResult < 0:
                        report += '[COLOR red]%s' % localized(32113)  # failed
                        if addon_item.applyPatchResult == -2:
                            report += '. %s' % localized(32114)  # reinstall needed
                        report += '[/COLOR]'
                    else:
                        report += '[COLOR red]%s[/COLOR]' % localized(32115)  # no apply, unknown reason
                elif addon_item.isSkippedVersion():
                    report += '[COLOR lime]%s[/COLOR]' % localized(32132)  # OK, no patch needed
                elif not addon_item.enabled:
                    report += '[COLOR orange]%s[/COLOR]' % localized(32118)  # is disabled by settings
                else:
                    report += '[COLOR red]%s[/COLOR]' % localized(32116)  # unsupported version
            else:
                report += '[COLOR yellow]%s[/COLOR]' % localized(32117)  # addon is not installed
            report += '\n'
        report += '\n[COLOR red]%s[/COLOR]' % localized(32119)
        xbmcgui.Dialog().textviewer('%s - %s' % (ADDON_NAME, localized(32100)), report, True)

    def updateAddonStatuses(self, checkDefs=False, showErrors=True, loggingInfos=True):
        saveE = self.dialogsEnabled
        saveL = self.loggingInfosEnabled
        try:
            self.dialogsEnabled = showErrors
            self.loggingInfosEnabled = loggingInfos
            if checkDefs:
                self.defsIsValid = False
            for addon_item in self.items:
                if checkDefs:
                    addon_item.checkPatchDefsFile()
                addon_item.updateStatus()
            if checkDefs:
                self.defsIsValid = True
        except PatchDefsError as err:
            self.defsIsValid = False
            self.showError(err.dlgMessage)
            msg = xbmc.getLocalizedString(2104) if showErrors else err.dlgMessage
            xbmcgui.Dialog().notification(ADDON_NAME + ' ' + xbmc.getLocalizedString(257), msg, xbmcgui.NOTIFICATION_ERROR, time=6000)
        finally:
            self.dialogsEnabled = saveE
            self.loggingInfosEnabled = saveL


class SysMonitor(xbmc.Monitor):

    def __init__(self, **kwargs):
        xbmc.Monitor.__init__(self)
        self.window = kwargs.get("win")
        self.owner = kwargs.get("owner")

    def onSettingsChanged(self):
        self.owner.logInfo('Monitor: settings changed')
        self.owner.settingsChanged = True

    def onNotification(self, sender, method, data):
        self.owner.logInfo('Monitor data: Sender: %s, Method: %s' % (str(sender), str(method)))
        if (sender == 'xbmc') and (method == 'Player.OnStop') and (self.owner.doShowNotify):
            self.owner.sleepTerminated = True


prop_status  = 'service.skpatch.status'
prop_running = 'service.skpatch.running'
prop_command = 'service.skpatch.command'


class Main(BaseClass):

    def __init__(self, asService):
        self.window = None
        self.isService = asService
        self.servicePaused = False
        self.serviceTerminated = False
        self.sleepTerminated = False
        self.settingsChanged = False
        self.doShowNotify = False

    def __logPrefix__(self):
        return '[%s service] ' % ADDON_NAME if self.isService else '[%s script] ' % ADDON_NAME

    def canShowInfo(self):
        return (not xbmc.getCondVisibility('[Player.Playing | Player.Paused | Player.Forwarding | Player.Rewinding]'))

    def getServiceStatus(self):
        # 0-not running, 1-paused, 2-running
        status = self.window.getProperty(prop_status)
        if (status is None) or (status == ''):
            return 0  # not running
        elif (status == 'paused'):
            return 1  # paused
        elif (status == 'runing'):
            return 2  # runing
        else:
            return 0

    def run(self):
        self.window = xbmcgui.Window(10000)
        try:
            if self.isService:
                if len(sys.argv) > 1:
                    forceStart = sys.argv[1] == 'force_start'
                else:
                    forceStart = False
                self.runService(forceStart)
            else:
                if len(sys.argv) > 1:
                    if sys.argv[1] == 'terminate_service':
                        if xbmcgui.Dialog().yesno(ADDON_NAME, localized(32129)):
                            self.logInfo('Terminating service invoked by user from settings dialog.')
                            if self.terminateService(wait=True) == 0:
                                ShowInfo(localized(32130))
                            else:
                                ShowInfo(localized(32125) + '.')
                    if sys.argv[1] == 'start_service':
                        cmd = 'RunScript(%s, force_start)' % os.path.join(CWD, 'service.py')
                        self.logInfo('ExecuteBuiltin = ' + cmd)
                        xbmc.executebuiltin(cmd)
                        c = 20
                        while c > 0:
                            xbmc.sleep(250)
                            c -= 1
                            res = self.getServiceStatus()
                            if res == 2:
                                ShowInfo(localized(32131))
                                return
                        ShowInfo(localized(32125) + '.')
                else:
                    self.runScript()
        finally:
            del self.window

    def pauseService(self, wait=False):
        # return service status
        if self.isService:
            self.servicePaused = True
            self.window.setProperty(prop_status, 'paused')
            self.logInfo('Service is paused.')
            return 1  # paused
        else:
            res = self.getServiceStatus()
            if res > 0:
                self.logDebug('Sending command to service: PAUSE, wait: %s' % str(wait))
                self.window.setProperty(prop_command, 'pause')
                if wait:
                    c = 20
                    while c > 0:
                        xbmc.sleep(250)
                        c -= 1
                        res = self.getServiceStatus()
                        if res < 2:
                            return res
                    self.logError('Service not responding to command PAUSE')
            return res

    def resumeService(self, wait=False):
        # return service status
        if self.isService:
            self.servicePaused = False
            self.window.setProperty(prop_status, 'runing')
            self.logInfo('Resume service.')
            return 2  # running
        else:
            res = self.getServiceStatus()
            if res == 1:
                self.logDebug('Sending command to service: RESUME, wait: %s' % str(wait))
                self.window.setProperty(prop_command, 'resume')
                if wait:
                    c = 20
                    while c > 0:
                        xbmc.sleep(250)
                        c -= 1
                        res = self.getServiceStatus()
                        if res == 2:
                            return res  # running
                    self.logError('Service not responding to command RESUME')
            return res

    def terminateService(self, wait=False):
        # return service status
        if self.isService:
            self.serviceTerminated = True
            return 0
        else:
            res = self.getServiceStatus()
            if res >= 0:
                self.logDebug('Sending command to service: TERMINATE, wait: %s' % str(wait))
                self.window.setProperty(prop_command, 'terminate')
                if wait:
                    c = 20
                    while c > 0:
                        xbmc.sleep(250)
                        c -= 1
                        res = self.getServiceStatus()
                        if res == 0:
                            return 0
                    self.logError('Service not responding to command TERMINATE')
            return res

    def procServiceCmds(self):
        if self.isService:
            # get command
            cmd = self.window.getProperty(prop_command)
            if (cmd is None) or (cmd == ''):
                return
            if (cmd == 'pause'):
                self.logDebug('Receive command PAUSE to pause service.')
                self.pauseService()
            elif (cmd == 'resume'):
                self.logDebug('Receive command RESUME to resume service.')
                self.resumeService()
            elif (cmd == 'terminate'):
                self.logInfo('Receive command TERMINATE to terminate service.')
                self.terminateService()
            else:
                self.logError('Receive unknown command: %s' % cmd)
            # clear command
            self.window.clearProperty(prop_command)

    def runScript(self):
        self.logInfo('Starting SK Patch script...')
        try:
            # pause service
            self.pauseService()
            try:
                if xbmcgui.Dialog().yesno(ADDON_NAME, localized(32126), '', localized(32127)):
                    if self.pauseService(wait=True) < 2:
                        addons = self.makeAddonList()
                        # addons.genSettingsFile()
                        addons.doPatchAddons(True)
                    else:
                        ShowError(localized(32125) + ': pause')
                else:
                    self.logInfo('Script process terminated by user.')
            finally:
                self.resumeService(wait=True)
        except PatchBaseError as err:
            ShowError(err.dlgMessage)
        finally:
            self.window.clearProperty('service.skpatch.command')
            self.logInfo('SK Patch script finished.')

    def runService(self, forceStart=False):
        self.isService = True
        monitor = None
        addons = None
        self.logInfo('Starting service...')
        if not forceStart:
            serviceEnabled = ADDON.getSettingBool('start_service')
            if not serviceEnabled:
                self.logInfo("Stop. Service is disabled by user's settings.")
                return
        lastHash = ''
        try:
            # self.pauseService()
            monitor = SysMonitor(win=self.window, owner=self)
            addons = self.makeAddonList()
            self.logInfo('Service started')
            self.window.setProperty(prop_running, 'true')
            self.resumeService()
            lcounter = 0
            notifyInterval = getNotifyInterval(ADDON.getSettingInt('notify_interval'))
            notifyIntCounter = notifyInterval
            # main service loop, run every 1 min
            while (not monitor.abortRequested()) and not self.serviceTerminated:
                if not self.servicePaused:
                    if self.settingsChanged:
                        notifyIntervalOld = notifyInterval
                        notifyInterval = getNotifyInterval(ADDON.getSettingInt('notify_interval'))
                        self.settingsChanged = False
                        if (notifyInterval != notifyIntervalOld):
                            elapsed = notifyIntervalOld - notifyIntCounter
                            if elapsed < notifyInterval:
                                notifyIntCounter = notifyInterval - elapsed
                            else:
                                notifyIntCounter = notifyInterval
                            del elapsed
                        del notifyIntervalOld
                    # update addon statuses, check defs files every 10 min, logging infos every 60 min
                    toLog = (lcounter % 60) == 0
                    if toLog:
                        self.logInfo('Checking supported add-ons status...')
                    addons.updateAddonStatuses(checkDefs=(lcounter % 10) == 0, showErrors=False, loggingInfos=toLog)
                    if not addons.defsIsValid:
                        if monitor.waitForAbort(6):
                            break
                        raise PatchBaseError(self, 'Patch definitions is not valid. Stopping service...', localized(32124))
                    installed, patched, actcount, statusHash = addons.getAddonStatuses()
                    if (installed > patched) and (actcount > 0):
                        # exists unpatched addon candidate
                        if (statusHash != lastHash) or (notifyIntCounter == 0):
                            # list of unpatched addons changed or notify delay time elapsed
                            self.doShowNotify = True
                            if self.canShowInfo():
                                if not toLog:
                                    # log infos
                                    self.logInfo('Checking supported add-ons status...')
                                    addons.updateAddonStatuses(checkDefs=False, showErrors=False, loggingInfos=True)
                                notifyIntCounter = notifyInterval
                                reason = 'Notify delay elapsed.' if statusHash == lastHash else 'Add-on status changed.'
                                self.logInfo('Show notification about unpatched add-on(s). %s' % reason)
                                del reason
                                lastHash = statusHash
                                self.doShowNotify = False
                                xbmcgui.Dialog().notification(ADDON_NAME, localized(32123), time=20000)
                            else:
                                self.logDebug('Can not show notification. Player is active.')
                lcounter += 1 if lcounter < 599 else 0
                if notifyIntCounter > 0:
                    notifyIntCounter -= 1
                else:
                    notifyIntCounter = notifyInterval
                # sleep/wait for abort, check/run command
                c = 20
                while not monitor.abortRequested() and (c > 0):
                    self.procServiceCmds()
                    if self.serviceTerminated or self.sleepTerminated:
                        break
                    c -= 1
                    if monitor.waitForAbort(3):
                        # Abort was requested
                        self.terminateService()
                        break
                self.sleepTerminated = False  
        except PatchBaseError as err:
            self.pauseService()
            xbmcgui.Dialog().notification(ADDON_NAME + ' ' + xbmc.getLocalizedString(257), err.dlgMessage + ' ' + xbmc.getLocalizedString(2104),
                                          xbmcgui.NOTIFICATION_ERROR, time=10000)
        except Exception as err:
            self.pauseService()
            xbmcgui.Dialog().notification(ADDON_NAME + ' ' + xbmc.getLocalizedString(257), err.message, xbmcgui.NOTIFICATION_ERROR, time=10000)
            if monitor.waitForAbort(5):
                return
            xbmcgui.Dialog().notification(ADDON_NAME + ' ' + xbmc.getLocalizedString(257), localized(32124), xbmcgui.NOTIFICATION_ERROR, time=10000)
            if monitor.waitForAbort(5):
                return
            raise
        finally:
            del monitor
            del addons
            self.window.clearProperty(prop_status)
            self.window.clearProperty(prop_running)
            self.logInfo('Service stopped.')

    def makeAddonList(self):
        al = AddonList(self)
        al.addAddon('skin.aeon.nox.silvo')
        al.addAddon('resource.language.sk_sk')
        al.addAddon('metadata.tvdb.com')
        al.addAddon('metadata.themoviedb.org')
        al.addAddon('metadata.tvshows.themoviedb.org')
        al.addAddon('metadata.serialzone.cz')
        al.addAddon('script.skinshortcuts')
        al.addAddon('script.skin.helper.colorpicker')
        al.addAddon('script.skin.helper.widgets')
        al.addAddon('script.skin.helper.service')
        al.addAddon('service.library.data.provider')
        al.addAddon('plugin.program.autocompletion')
        al.addAddon('script.common.plugin.cache')
        al.addAddon('script.cu.lrclyrics')
        al.addAddon('script.globalsearch')
        al.addAddon('script.artistslideshow')
        al.addAddon('script.module.metadatautils')
        al.addAddon('metadata.artists.universal')
        return al
