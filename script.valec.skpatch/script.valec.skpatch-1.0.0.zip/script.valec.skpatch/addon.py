# -*- coding: UTF-8 -*-
# /*
# *      Copyright (C) 2019 Miro "Valec" Valko
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */

import os
import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import xml.etree.ElementTree as ET

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')


def VersionTuple(v):
    return tuple(map(int, (v.split("."))))


def CompareVersions(Ver1, Ver2):
    v1 = VersionTuple(Ver1)
    v2 = VersionTuple(Ver2)
    if (v1 > v2):
        return 1
    elif (v1 < v2):
        return -1
    else:
        return 0


def ShowError(MsgStr1, MsgStr2='', MsgStr3=''):
    if MsgStr3 == "":
        MsgStr3 = 'Bližšie info nájdete v denníku udalostí.'
    xbmcgui.Dialog().ok(addon.getAddonInfo('name') + ' - CHYBA !!!', MsgStr1, MsgStr2, MsgStr3)


class PatchException(Exception):
    pass


class AddonItem:

    def __init__(self, addonID):
        self.addonID = addonID
        self.name = addonID
        self.version = ''
        self.srcpath = os.path.join(addon.getAddonInfo('path'), 'resources', 'data', addonID)
        self.enabled = False
        self.patched = False
        self.installed = xbmc.getCondVisibility("System.HasAddon(%s)" % addonID)
        self.actionscount = 0
        if self.installed:
            self.addon = xbmcaddon.Addon(addonID)
            self.name = self.addon.getAddonInfo('name')
            self.version = self.addon.getAddonInfo('version')
            self.destpath = self.addon.getAddonInfo('path')
            self.patchfile = os.path.join(self.srcpath, 'patch.xml')
            # check patch file
            if xbmcvfs.exists(self.patchfile):
                try:
                    self.tree = ET.parse(self.patchfile.decode('utf-8'))
                    root = self.tree.getroot()
                    aid = root.attrib.get('id')
                    if (root.tag == 'addon') & (aid == addonID):
                        # find patch section with valid version
                        for patch_elem in root.findall('patch'):
                            self.actionscount = 0
                            if self.IsValidVersion(patch_elem.attrib.get('versions', 'all')):
                                for action in patch_elem.findall('action'):
                                    fn = action.attrib.get('file')
                                    if (fn is None) or (fn == ''):
                                        self.LogError('Error in file: %s\n%s [Action id = %s]' % (self.patchfile, 'Missing file definition for action.', action.attrib.get('id')))
                                        raise PatchException()
                                    at = action.attrib.get('type')
                                    if at is None:
                                        self.LogError('Error in file: %s\n%s [Action id = %s]' % (self.patchfile, 'Missing type of action.', action.attrib.get('id')))
                                        raise PatchException()
                                    validtypes = ['COPYFILE', 'XMLUPDATE']
                                    if validtypes.count(at.upper()) == 0:
                                        self.LogError('Error in file: %s\n%s : %s [Action id = %s]' % (self.patchfile, 'Invalid type of action', at, action.attrib.get('id')))
                                        raise PatchException()
                                    self.actionscount += 1
                                self.enabled = True
                                self.patch = patch_elem
                                break   # patch element iteration
                        if self.enabled:
                            self.LogInfo('Valid version of patch is found. Patch actions: %d' % (self.actionscount))
                        else:
                            self.LogWarning('No valid version of patch is found.')
                    else:
                        self.LogError('Error in file: %s\n%s' % (self.patchfile, 'Invalid <addon id=xxx> element.'))
                        raise PatchException()
                except:
                    ShowError('Súbor popisu opráv pre doplnok "%s" [%s] obsahuje nekonzistentné údaje.' % (self.name, addonID))
                    self.LogError('Error has occured. Patch file: %s' % (self.patchfile))
                    raise
            else:
                self.LogError('Missing file: %s' % (self.patchfile))
                ShowError('Chýba popis opráv pre doplnok "%s" [%s].' % (self.name, addonID))
        else:
            self.LogInfo('Addon is not installed.')

    def IsValidVersion(self, versions):
        if (versions == '') or (versions == 'all'):
            return True
        verlist = versions.split(',')
        for veritem in verlist:
            vl = veritem.strip().split(':')
            if len(vl) == 1:
                vmin = vl[0].strip()
                vmax = vmin
            elif len(vl) == 2:
                vmin = vl[0].strip()
                vmax = vl[1].strip()
            else:
                self.LogError('Error in file: %s\n%s [%s]' % (self.patchfile, 'Invalid version definition.', versions))
                raise PatchException()
            cmpmin = CompareVersions(self.version, vmin)
            cmpmax = CompareVersions(self.version, vmax)
            if (cmpmin >= 0) and (cmpmax <= 0):
                return True
        return False

    def LogMessage(self, MsgStr, level=xbmc.LOGNOTICE):
        xbmc.log('[%s] Patch: %s: %s' % (addon.getAddonInfo('id'), self.addonID, MsgStr), level)

    def LogDebug(self, MsgStr):
        self.LogMessage(MsgStr, level=xbmc.LOGDEBUG)

    def LogError(self, MsgStr):
        self.LogMessage(MsgStr, level=xbmc.LOGERROR)

    def LogInfo(self, MsgStr):
        self.LogMessage(MsgStr, level=xbmc.LOGNOTICE)

    def LogWarning(self, MsgStr):
        self.LogMessage(MsgStr, level=xbmc.LOGWARNING)

    def Update(self, progress, lastidx, total):
        perc = (100/total) * (lastidx)
        progress.update(perc, '', '%s [%s]' % (self.name, self.addonID), ' ')
        xbmc.sleep(100)
        root = self.tree.getroot()
        self.patched = False
        self.failed = False
        modified = False
        actcount = 0
        try:
            for action in self.patch.findall('action'):
                perc = (100/total)*(lastidx+actcount)
                progress.update(perc)
                xbmc.sleep(100)
                actcount += 1
                fn = action.attrib.get('file')
                at = action.attrib.get('type').upper()
                if (at == 'COPYFILE'):
                    # copy file
                    progress.update(perc, '', '', 'Kopírujem súbor ' + fn)
                    srcfile = os.path.join(self.srcpath, action.attrib.get('source', fn))
                    destfile = os.path.join(self.destpath, fn)
                    if xbmcvfs.exists(srcfile):
                        if xbmcvfs.copy(srcfile, destfile):
                            modified = True
                        else:
                            self.LogError('Copy file failed: ' + srcfile)
                            raise PatchException()
                    else:
                        self.LogError('Copy file failed. Source file does not exists : ' + srcfile)
                        raise PatchException()
                elif (at == 'XMLUPDATE'):
                    # update xml
                    xml_modified = False
                    progress.update(perc, '', '', 'Aktualizujem súbor ' + fn)
                    destfile = os.path.join(self.destpath, fn)
                    if xbmcvfs.exists(destfile):
                        dest_tree = ET.parse(destfile.decode('utf-8'))
                        dest_root = dest_tree.getroot()
                        for elm in action.findall('element'):
                            elm_path = elm.attrib.get('xpath')
                            fkeysstr = elm.attrib.get('keys')
                            fkeys = []
                            allatributes = (fkeysstr is None) or (fkeysstr == '')
                            if not allatributes:
                                fkeys2 = fkeysstr.split(',')
                                for k in fkeys2:
                                    fkeys.append(k.strip())
                            dest_parent = dest_root.find(elm_path)
                            if dest_parent is None:
                                self.LogError('Cant find xml element with xpath=' + elm_path)
                                raise PatchException
                            for item in elm.findall("./*"):
                                new_element = item.copy()
                                # get same element position in original file
                                query = './' + item.tag
                                if allatributes:
                                    fkeys = item.attrib.keys()
                                for attr in fkeys:
                                    aq = "[@%s='%s']" % (attr, item.attrib.get(attr))
                                    query += aq
                                dest_element = dest_parent.find(query)
                                if dest_element is not None:
                                    # same element exists, get index and replace
                                    idx = dest_parent._children.index(dest_element)
                                    new_element.tail = dest_element.tail
                                    dest_parent.__setitem__(idx, new_element)
                                    xml_modified = True
                                else:
                                    # element does not exists, find last similar
                                    query = './' + item.tag + '[last()]'
                                    dest_element = dest_parent.find(query)
                                    if dest_element is not None:
                                        # similar element exists, get the index
                                        new_element.tail = dest_element.tail
                                        idx = dest_parent._children.index(dest_element)
                                        dest_parent.insert(idx+1, new_element)
                                    else:
                                        dest_parent.append(new_element)
                                    xml_modified = True
                        if xml_modified:
                            modified = True
                            dest_tree.write(destfile.decode('utf-8'), encoding="utf-8", xml_declaration=True)
                    else:
                        self.LogError('File not found: ' + destfile)
                        raise PatchException()
            perc = (100/total)*(lastidx+self.actionscount)
            progress.update(perc)
            self.patched = True
        except:
            self.failed = True
            self.patched = False
            msg2 = 'Zmeny vrátite reinštaláciou/aktualizáciou doplnku.' if modified else ''
            ShowError('Úprava doplnku "%s" [%s] zlyhala.' % (self.name, self.addonID), msg2)


class Addons:

    def __init__(self):
        self.items = []

    def AddAddon(self, addonID):
        self.items.append(AddonItem(addonID))

    def GetActionsCount(self, All=False):
        total = 0
        for ai in self.items:
            if (ai.enabled or All):
                total += ai.actionscount
        return total

    def UpdateAddons(self):
        lastidx = 0
        total = self.GetActionsCount()
        if total > 0:
            progress = xbmcgui.DialogProgress()
            progress.create(addon.getAddonInfo('name'), 'Modifikujem doplnky ...')
            for addon_item in self.items:
                if addon_item.enabled:
                    addon_item.Update(progress, lastidx, total)
                    lastidx += addon_item.actionscount
                    xbmc.sleep(100)
            progress.update(100, 'Modifikácia ukončená.', ' ', ' ')
            xbmc.sleep(500)
            xbmc.executebuiltin('UpdateLocalAddons')
            progress.close()
        self.ShowUpdateInfo()

    def ShowUpdateInfo(self):
        report = '[COLOR cyan][B]Výsledok úpravy doplnkov za účelom podpory slovenčiny:[/B][/COLOR] \n'
        i = 0
        idlen = 2 if len(self.items) > 9 else 1
        for addon_item in self.items:
            i += 1
            report += '\n%*.*d/%d - [B]%s[/B],  verzia: %s\n    ... ' % (idlen, idlen, i, len(self.items), addon_item.addonID, addon_item.version)
            if addon_item.installed:
                if addon_item.enabled:
                    if addon_item.patched:
                        report += '[COLOR lime]úprava OK[/COLOR]'
                    elif addon_item.failed:
                        report += '[COLOR red]úprava zlyhala. Reinštalujte doplnok !!![/COLOR]'
                else:
                    report += '[COLOR red]úprava nevykonaná - nepodporovaná verzia doplnku[/COLOR]'
            else:
                report += '[COLOR yellow]doplnok nie je nainštalovaný[/COLOR]'
            report += '\n'
        report += '\n\n[COLOR cyan]Po aktualizácii niektorého z podporovaných doplnkov nezabudnite znovu spustiť doplnok SK Patch ![/COLOR]'
        xbmcgui.Dialog().textviewer(addon.getAddonInfo('name') + ' - Výsledok', report, True)
        if xbmcgui.Dialog().yesno(addon.getAddonInfo('name'), 'Pre aplikovanie zmien je nutný reštart Kodi.', '', 'Prajete si Kodi reštartovať teraz ?'):
            xbmc.executebuiltin('RestartApp')


addons = Addons()
addons.AddAddon('skin.aeon.nox.silvo')
addons.AddAddon('resource.language.sk_sk')
addons.AddAddon('metadata.tvdb.com')
addons.AddAddon('metadata.themoviedb.org')
addons.AddAddon('metadata.tvshows.themoviedb.org')
addons.AddAddon('metadata.serialzone.cz')
addons.AddAddon('script.skinshortcuts')
addons.AddAddon('script.skin.helper.colorpicker')
addons.AddAddon('script.skin.helper.widgets')
addons.AddAddon('service.library.data.provider')
addons.UpdateAddons()
