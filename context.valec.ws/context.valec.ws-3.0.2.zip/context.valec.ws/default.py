# -*- coding: utf-8 -*-


import sys
import xbmc
import os
import xbmcgui
import xbmcplugin
import xbmcaddon
from urlparse import parse_qsl


RES_LIB = (os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
sys.path.append(RES_LIB)

import webshare

webshare.run()