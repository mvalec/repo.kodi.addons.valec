# -*- coding: utf-8 -*-

import webshare
webshare.get_vip()