# -*- coding: utf8 -*-

import os
import xbmcaddon
import routing
import xbmcgui
import xbmcplugin


RES_LIB = (os.path.join(os.path.dirname(__file__), 'resources', 'lib'))
sys.path.append(RES_LIB)

import webshare

plugin = routing.Plugin()

class Main:

    def __init__(self):

        self._parse_argv()
        for info in self.infos:
            listitems = process.start_info_actions(info, self.params)
            if listitems:
                listitems.set_plugin_list(plugin.handle)
            break
        else:
            plugin.run()

    def _parse_argv(self):
        args = sys.argv[2][1:]
        self.infos = []
        self.params = {"handle": plugin.handle}


@plugin.route('/play/<ident>')
def play(ident):
    url = webshare.get_stream_url(ident)
    listitem = xbmcgui.ListItem(path=url)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(plugin.handle, True, listitem)


if (__name__ == "__main__"):
    Main()
