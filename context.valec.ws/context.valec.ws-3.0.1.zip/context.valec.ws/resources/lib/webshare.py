# -*- coding: utf-8 -*-

import sys
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import hashlib
import json
import urlparse
from urllib2 import urlopen, Request
from xml.etree import ElementTree as ET
from md5crypt import md5crypt
from urllib import urlencode, quote



reload(sys)
sys.setdefaultencoding('utf8')
addon = xbmcaddon.Addon(id='context.valec.ws')
userpath = addon.getAddonInfo('profile')
ident_path = xbmc.translatePath("%s/ident.txt" % userpath).decode('utf-8')
vs = {'0': '', '1': 'largest', '2': 'recent'}


def get_pass_digest(username, realm, password, salt):
    encrypted_pass = hashlib.sha1(md5crypt(password.encode('utf-8'), salt.encode('utf-8'))).hexdigest()
    return {'password': encrypted_pass, 'digest': hashlib.md5(username.encode('utf-8') + realm + encrypted_pass.encode('utf-8')).hexdigest()}


def login():
    username = addon.getSetting('user')
    password = addon.getSetting('pass')
    request = Request('http://webshare.cz/api/salt/', data = urlencode({'username_or_email': username}))
    req = urlopen(request).read()
    status = ET.fromstring(req).find('status').text
    if status == 'OK':
        salt = ET.fromstring(req).find('salt').text
        pass_digest = get_pass_digest(username, ':Webshare:', password, salt)
        request = Request('http://webshare.cz/api/login/', data = urlencode({ 'username_or_email': username, 'password': pass_digest['password'], 'digest': pass_digest['digest'], 'keep_logged_in': 1 }))
        req = urlopen(request).read()
        status = ET.fromstring(req).find('status').text
        if status == 'OK':
            token = ET.fromstring(req).find('token').text
            return token
        else:
            message = ET.fromstring(req).find('message').text
            xbmcgui.Dialog().notification("Webshare",message, xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)
    else:
        message = ET.fromstring(req).find('message').text
        xbmcgui.Dialog().notification("Webshare",message, xbmcgui.NOTIFICATION_ERROR, 4000, sound = False)


def get_vip():
    token = login()
    if token:
        request = Request('http://webshare.cz/api/user_data/', data = urlencode({'wst': token}))
        req = urlopen(request).read()
        vip = ET.fromstring(req).find('status').text
        if vip == 'OK':
            u = ET.fromstring(req).find('username').text
            e = ET.fromstring(req).find('email').text
            v = ET.fromstring(req).find('vip_days').text
            xbmcgui.Dialog().ok('Webshare', addon.getLocalizedString(32002)+': ' + u, 'Email: ' + e, addon.getLocalizedString(32034) + v)



def get_stream_url(ident):
    token = login()
    if token:
        request = Request('http://webshare.cz/api/file_link/', data = urlencode({'wst': token, 'ident': ident}))
        req = urlopen(request).read()
        link = ET.fromstring(req).find('link').text
        return link


def convert_size(number_of_bytes):
    if number_of_bytes < 0:
        raise ValueError("!!! number_of_bytes can't be smaller than 0 !!!")
    step_to_greater_unit = 1024.
    number_of_bytes = float(number_of_bytes)
    unit = 'bytes'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'KB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'MB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'GB'
    if (number_of_bytes / step_to_greater_unit) >= 1:
        number_of_bytes /= step_to_greater_unit
        unit = 'TB'
    precision = 1
    number_of_bytes = round(number_of_bytes, precision)
    return str(number_of_bytes) + ' ' + unit


def del_history():
    token = login()
    if token:
        request = Request('http://webshare.cz/api/clear_history/', data = urlencode({'wst': token}))
        req = urlopen(request).read()
        xml = ET.fromstring(req)
        if xml.find('status').text == 'OK':
            xbmcgui.Dialog().notification("Webshare",getLocalizedString(19179), xbmcgui.NOTIFICATION_INFO, 3000, sound = False)


def history():
    token = login()
    if token:
        request = Request('http://webshare.cz/api/history/', data = urlencode({'wst': token}))
        req = urlopen(request).read()
        xml = ET.fromstring(req)
        if xml.find('status').text == 'OK':
            name_list = []
            for file in xml.findall('file'):
                name = file.find('name').text
                url = file.find('ident').text
                size = int(file.find('size').text)
                nl = ('[' + convert_size(size) + '] ' + name, url)
                if nl not in name_list:
                    name_list.append(nl)
            if name_list != []:
                name_list.append(('[COLOR blue]'+addon.getLocalizedString(32035)+'[/COLOR]', ''))
            index = xbmcgui.Dialog().select(addon.getLocalizedString(32036), [x[0] for x in name_list])
            if index == -1:
                return

            else:
                if index == len(name_list) - 1:
                    del_history()
                else:
                    streamUrl = get_stream_url(str(name_list[index][1]))
                    if streamUrl:
                        listItem = xbmcgui.ListItem(path=streamUrl)
                        xbmc.Player().play(item=streamUrl, listitem=listItem)


def set_query_ws(title):
    kb = xbmc.Keyboard(title, addon.getLocalizedString(32037))
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText()
    if query == "":
        return
    request = Request('http://webshare.cz/api/search/', data = urlencode({'wst': '', 'offset': 0, 'limit': 20, 'category': 'video', 'sort': vs[addon.getSetting('sorting')], 'what': query}))
    req = urlopen(request).read()
    xml = ET.fromstring(req)
    if xml.find('status').text == 'OK':
        name_list = []
        for file in xml.findall('file'):
            name = file.find('name').text
            url = file.find('ident').text
            size = int(file.find('size').text)
            name_list.append(('[' + convert_size(size) + '] ' + name, url))
        index = xbmcgui.Dialog().select('WEBSHARE', [x[0] for x in name_list])
        if index == -1:
            return

        else:
            streamUrl = get_stream_url(str(name_list[index][1]))
            if streamUrl:
                listItem = xbmcgui.ListItem(path=streamUrl)
                xbmc.Player().play(item=streamUrl, listitem=listItem)


def get_stream_list_ws():
    title = xbmc.getInfoLabel("ListItem.Title")
    year = xbmc.getInfoLabel("ListItem.Year")
    dbtype = xbmc.getInfoLabel("ListItem.DBTYPE")
    if dbtype == 'episode':
        name = xbmc.getInfoLabel("ListItem.TVShowTitle")
        query = name + ' ' + title.split(' - ')[0]

    elif dbtype == 'movie':
        query = title.split(' - ')[0] + ' ' + year
    elif dbtype == 'video':
        query = title.split('B]')[1].replace('[/', '') + ' ' + year
    request = Request('http://webshare.cz/api/search/', data = urlencode({'wst': '', 'offset': 0, 'limit': 20, 'category': 'video', 'sort': vs[addon.getSetting('sorting')], 'what': query}))
    req = urlopen(request).read()
    xml = ET.fromstring(req)
    if xml.find('status').text == 'OK':
        name_list = []
        for file in xml.findall('file'):
            name = file.find('name').text
            url = file.find('ident').text
            size = int(file.find('size').text)
            name_list.append(('[' + convert_size(size) + '] ' + name, url))
        name_list.append(('[COLOR blue]'+addon.getLocalizedString(32038)+'[/COLOR]', ''))
        index = xbmcgui.Dialog().select('WEBSHARE', [x[0] for x in name_list])
        if index == -1:
            return

        else:
            if index == len(name_list) - 1:
                set_query_ws(query)
            else:
                try:
                    f = open(ident_path, "w")
                    f.write(xbmc.getInfoLabel("ListItem.OriginalTitle") + '\n' + str(name_list[index][1]))
                    f.close()
                except:
                    pass
                streamUrl = get_stream_url(str(name_list[index][1]))
                if streamUrl:
                    listItem = xbmcgui.ListItem(path=streamUrl)
                    if dbtype == 'movie':
                        listItem.setInfo(type='Video', infoLabels={'OriginalTitle':xbmc.getInfoLabel("ListItem.OriginalTitle")})
                    xbmc.Player().play(item=streamUrl, listitem=listItem)


def get_stream_list_movies(id):
    try:
        req = urlopen('http://plugin.sc2.zone/api/media/movies/' + id, timeout = 10).read()
        req = json.loads(req)
        streams = req['streams']
        name_list = []
        for name in streams:
            name_list.append("[B][" + name['lang'] + '] ' + name['quality'] + '[/B] - ' + name['size'] + name['ainfo'])
        if name_list == []:
            get_stream_list_ws()
            return
        name_list.append('[COLOR blue]'+addon.getLocalizedString(32031)+'[/COLOR]')
        index = xbmcgui.Dialog().select(req['originaltitle'], name_list)
        if index == -1:
            return
        else:
            if name_list[index] == addon.getLocalizedString(32031):
                get_stream_list_ws()
            else:
                try:
                    f = open(ident_path, "w")
                    f.write(req['originaltitle'] + '\n' + str(streams[index]['ident']))
                    f.close()
                except:
                    pass
                streamUrl = get_stream_url(str(streams[index]['ident']))
                if streamUrl:
                    listItem = xbmcgui.ListItem(path=streamUrl)
                    listItem.setInfo(type='Video', infoLabels={'OriginalTitle':req['originaltitle']})
                    xbmc.Player().play(item=streamUrl, listitem=listItem)
    except:
        get_stream_list_ws()


def get_stream_list_episodes(id, se, ep):
    try:
        req = urlopen('http://plugin.sc2.zone/api/media/series/' + id, timeout=10).read()
        req = json.loads(req)
        streams = req['seasons'][int(se) - 1]['episodes'][int(ep) - 1]['strms']
        name_list = []
        for name in streams:
            name_list.append("[B][" + name['lang'] + '] ' + name['quality'] + '[/B] - ' + name['size'] + name['ainfo'])
        if name_list == []:
            get_stream_list_ws()
            return
        name_list.append('[COLOR blue]'+addon.getLocalizedString(32031)+'[/COLOR]')
        index = xbmcgui.Dialog().select(req['originaltitle'], name_list)
        if index == -1:
            return
        else:
            if name_list[index] == addon.getLocalizedString(32031):
                get_stream_list_ws()
            else:
                streamUrl = get_stream_url(str(streams[index]['ident']))
                if streamUrl:
                    listItem = xbmcgui.ListItem(path=streamUrl)
                    xbmc.Player().play(item=streamUrl, listitem=listItem)
    except:
        get_stream_list_ws()


def run():
    path = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    parsed = urlparse.urlparse(path)

    dbtype = xbmc.getInfoLabel("ListItem.DBTYPE")
    if dbtype == 'movie' or dbtype == 'video':
        id = str((urlparse.parse_qs(parsed.query)['play'][0].decode('hex')).split('/')[-1])

        get_stream_list_movies(id)
    else:
        id = str((urlparse.parse_qs(parsed.query)['play'][0].decode('hex')).split('/')[-3])

        se = str((urlparse.parse_qs(parsed.query)['play'][0].decode('hex')).split('/')[-2])
        ep = str((urlparse.parse_qs(parsed.query)['play'][0].decode('hex')).split('/')[-1])
        get_stream_list_episodes(id, se, ep)
