# -*- coding: utf-8 -*-


import sys
import xbmc
import os
import xbmcgui
import xbmcplugin
import xbmcaddon
from urlparse import parse_qsl


__addon__ = xbmcaddon.Addon()
__cwd__        = xbmc.translatePath( __addon__.getAddonInfo('path') ).decode("utf-8")
__resource__   = xbmc.translatePath( os.path.join( __cwd__, 'resources', 'lib' ) ).decode("utf-8")
sys.path.append (__resource__)
import webshare


try    : HANDLE = int(sys.argv[1])
except : HANDLE = -1


def play(url,):
    listitem = xbmcgui.ListItem(path=url)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(HANDLE, True, listitem)


def main():
    if len(sys.argv) > 1:
        params = dict(parse_qsl(sys.argv[2][1:]))
        if params:
            if params["action"] == "play":
                streamUrl = webshare.get_stream_url(params["ident"])
                if streamUrl:
                    play(streamUrl)
    else:
        try:
            webshare.run()
        except:
            webshare.history()


if __name__ == '__main__':
    main()