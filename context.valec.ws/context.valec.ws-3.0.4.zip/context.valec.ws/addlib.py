# -*- coding: utf-8 -*-

import sys
import os
import xbmc
import xbmcgui
import xbmcaddon


reload(sys)
sys.setdefaultencoding('utf8')
addon = xbmcaddon.Addon(id='context.valec.ws')
userpath = addon.getAddonInfo('profile')


try:
    ident_path = xbmc.translatePath("%s/ident.txt" % userpath)
    ident = open(ident_path).read().split('\n')
    f = open(addon.getSetting('library') + ident[0].encode('utf-8') + '.strm' , 'w')
    f.write('plugin://context.valec.ws/play/' + ident[1].encode('utf-8'))
    f.close()
    xbmc.executebuiltin('XBMC.UpdateLibrary(video)')
    os.remove(ident_path)
    xbmcgui.Dialog().notification('Webshare',xbmc.getLocalizedString(35259), xbmcgui.NOTIFICATION_INFO, 3000, sound = False)
    sys.exit(0)
except:
    sys.exit(0)